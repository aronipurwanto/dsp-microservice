package com.dsp.microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelajarSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
