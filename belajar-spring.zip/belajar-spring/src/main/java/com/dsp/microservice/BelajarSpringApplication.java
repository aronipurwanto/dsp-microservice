package com.dsp.microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BelajarSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelajarSpringApplication.class, args);
	}

}
